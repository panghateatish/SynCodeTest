package com.syn.service;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

import com.syn.model.Employee;

public class FilterAndSortList {

	public static void main(String[] args) {
		// test list data
		List<Employee> employeeList = Arrays.asList(new Employee(30, "Suhas"), new Employee(25, "Parag"),
				new Employee(28, "Vikas"), new Employee(35, "Jack"));

		// filter on age and sort on first name
		final List<Employee> sortedEmployeeList = employeeList.stream().filter(emp -> emp.getAge() > 26)
				.sorted((emp1, emp2) -> emp1.getFirstname().compareTo(emp2.getFirstname()))
				.collect(Collectors.toList());

		// print list
		System.out.println(sortedEmployeeList);

	}

}
