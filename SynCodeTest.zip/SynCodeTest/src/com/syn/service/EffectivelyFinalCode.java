package com.syn.service;

public class EffectivelyFinalCode {

	public static void main(String[] args) {

		String s = "hello";

		// below line if uncommented will result in compiler error
		// s = "hello 1";

		Runnable r = () -> System.out.println(s + "world");

	}
}
