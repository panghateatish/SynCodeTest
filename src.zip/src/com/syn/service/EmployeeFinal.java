package com.syn.service;

import java.util.Date;

public final class  EmployeeFinal {
	
	private final String name;
	private final Date dob;
	private final int age;
	
	public EmployeeFinal(String name, Date dob, int age) {
		this.name = name;
		this.age = age;
		this.dob = new Date(dob.getTime()); // defensive copy
	}

	public String getName() {
		return name;
	}

	public Date getDob() {
		return (Date)dob.clone(); // returning clone so caller can't modify
	}

	public int getAge() {
		return age;
	}
	
	
	
	
	
	
	
	

}
