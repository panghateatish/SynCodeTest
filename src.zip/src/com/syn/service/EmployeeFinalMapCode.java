package com.syn.service;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

public class EmployeeFinalMapCode {
	
	public static void main(String[] args) {
		
		Map<EmployeeFinal,String> employeeMap= new HashMap<>();
		
		EmployeeFinal emp1=new EmployeeFinal("test",new Date(),30);
		
		employeeMap.put(emp1, "Tech");
		
		System.out.println(employeeMap.get(emp1));
		
		
		
		
		
	}

}
